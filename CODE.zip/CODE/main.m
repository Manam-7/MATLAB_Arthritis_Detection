clc;    %Clear Command Window
clear;  %Remove items from workspace, freeing up system memory
close all;  %Remove specified figure
warning off;    %Don't Display warning message

%% Image Selection & Reading
[filename,pathname]=uigetfile('*.*','Select an image'); %Open file selection dialog box
img=imread([pathname,filename]);    %Read image from graphics file
figure;     %Create figure window
imshow(img);    %Display image
title('Input Image');   %Add title
%%
prompt = {'Please Enter Number of Control Points'};
Controlpoints = inputdlg(prompt);   %Create dialog box to gather user input
Controlpoints = cell2mat(Controlpoints);    %Convert cell array to ordinary array of the underlying data type
Controlpoints = str2num(Controlpoints);     %Convert character array to numeric array
n1=Controlpoints-1;
figure;
axis([0 100 0 100]);    %Set axis limits and aspect ratios
image(img);title('Selected Control Points');
p=ginput(Controlpoints);    %Graphical input from mouse or cursor

for i=0:1:n1
sigma(i+1)=factorial(n1)/(factorial(i)*factorial(n1-i));  % for calculating (x!/(y!(x-y)!)) values 
end
l=[];
UB=[];
for u=0:0.002:1
for d=1:Controlpoints
UB(d)=sigma(d)*((1-u)^(Controlpoints-d))*(u^(d-1));
end
l=cat(1,l,UB);                                      %catenation 
end
P=l*p;
line(P(:,1),P(:,2))
%%
Idiffusion = imdiffusefilt(img);    %Anisotropic diffusion filtering of images
figure;imshow(Idiffusion);title('Anisotropic diffusion');
%%
c = rgb2gray(Idiffusion);   %Convert RGB image or colormap to grayscale
canny_edge = edge(c,'Canny');   %Find canny edges in intensity image
figure;imshow(canny_edge);title('Canny Edge Detection');
%%
log_edge= edge(canny_edge,'log');   %Find log edges in intensity image
figure;imshow(log_edge);title('Log Edge Detection');
%%
figure;imshow(log_edge);title('Control Points Adjustment Image');
line(P(:,1),P(:,2),'LineWidth',5)   %Create primitive line
%%
thick = mean(sum(p,2)/100); %Average or mean value of array
fprintf('Thickness = %f\n',thick);
%%
if thick <= 3.7         %Setting the thresholding
    disp('Abnormal')    %Display value of variable
else
    disp('Normal')
end
%%





